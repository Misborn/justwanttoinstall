1. Use `cargo run` to generate rust bindings at `lib_gen.rs`

2. Copy `lib_gen.rs` to `cras-sys/src/gen.rs
